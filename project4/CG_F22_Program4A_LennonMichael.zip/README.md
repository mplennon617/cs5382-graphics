# CS 7382 Program 4

## Access Images

`robin-square.png` and `StyleGAN2FaceSmall.png` are included in the submission .zip folder, and are required to be in the same directory as the project .js and .html files.